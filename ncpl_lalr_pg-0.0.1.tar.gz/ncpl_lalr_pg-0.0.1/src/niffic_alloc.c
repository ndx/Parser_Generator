
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"niffic_alloc.h"
#include<stdio.h>
#include<assert.h>

static unsigned long checksum(void *buf)
{
    unsigned char *b = buf, *bend = buf+sizeof(niffic_buffer_t);
    unsigned long sum = 0;
    for(; b<bend; b++) sum += (*b)*65599;
    return sum;
}

/*
 * buffer
 */
static niffic_buffer_t *niffic_new_buf(niffic_pool_t *pool,\
niffic_list_t *list, niffic_block_t *blk, unsigned long size)
{
    niffic_buffer_t *buf = (niffic_buffer_t *)calloc(1, sizeof(niffic_buffer_t));
    if( buf==NULL ) return NULL;
    buf->buf = calloc(1, size+ADDLEN);
    if( buf->buf==NULL ) { free(buf); return NULL;}
    buf->pool = pool;
    buf->list = list;
    buf->blk = blk;
    return buf;
}

static void niffic_free_buf(niffic_buffer_t *buf)
{
    if( buf->buf!=NULL ) free(buf->buf);
    free(buf);
}

/*
 * block
 */
static niffic_block_t *niffic_new_blk(void)
{
    return (niffic_block_t *)calloc(1, sizeof(niffic_block_t));
}

static void niffic_free_blk(niffic_block_t *blk)
{
    if( blk->buf!=NULL ) niffic_free_buf(blk->buf);
    free(blk);
}

static void niffic_add_blk(niffic_block_t *blk, niffic_block_t **head)
{
    if( *head==NULL ) {
        *head = blk;
        return;
    }
    blk->next = *head;
    (*head)->prev = blk;
    *head = blk;
}

static niffic_block_t *niffic_del_blk(niffic_block_t *blk, niffic_block_t **head)
{
    if( *head==NULL ) return NULL;
    if( *head==blk ) {
        *head = blk->next;
        if( *head!=NULL ) (*head)->prev = NULL;
    } else {
        blk->prev->next = blk->next;
        if( blk->next!=NULL ) blk->next->prev = blk->prev;
    }
    blk->next = blk->prev = NULL;
    return blk;
}

/*
 * pool
 */
niffic_pool_t *niffic_new_pool(unsigned long limit, unsigned long nrblk_limit)
{
    niffic_pool_t *pool = (niffic_pool_t *)calloc(1, sizeof(niffic_pool_t));
    if( pool==NULL ) return NULL;
    pool->limit = limit;
    pool->nrblk_limit = nrblk_limit;
    return pool;
}

void niffic_free_pool(niffic_pool_t *pool)
{
    niffic_list_t *l, *lend = pool->list + (sizeof(long *)<<3);
    niffic_block_t *blk;
    for(l = pool->list; l<lend; l++) {
        while( (blk = niffic_del_blk(l->used, &(l->used)))!=NULL )
            niffic_free_blk(blk);
        while( (blk = niffic_del_blk(l->free, &(l->free)))!=NULL )
            niffic_free_blk(blk);
    }
    free(pool);
}

/*
 * alloc
 */
#ifdef __DEBUG
void *niffic_alloc(niffic_pool_t *pool, unsigned long size)
{
    return calloc(1, size);
}
#else
void *niffic_alloc(niffic_pool_t *pool, unsigned long size)
{
    if( pool==NULL || !size ) return NULL;
    unsigned long blk_size = 0, index = 0;
    while( 1 ) {
        blk_size = (((unsigned long)1)<<index);
        if( blk_size>=size ) break;
        index++;
    }
    if( pool->limit!=N_M_INFINITE && pool->used+blk_size>pool->limit )
        return NULL;
    niffic_list_t *nl = &(pool->list[index]), *lend;
    niffic_block_t *blk;
lp: blk = niffic_del_blk(nl->free, &(nl->free));
    if( blk==NULL ) {
        blk = niffic_new_blk();
        if( blk==NULL ) {
non:        lend = pool->list+(sizeof(long *)<<3);
            for(; nl<lend && nl->free==NULL; nl++);
            if( nl>=lend ) return NULL;
            goto lp;
        }
        blk->buf = niffic_new_buf(pool, nl, blk, blk_size);
        if( blk->buf==NULL ) {
            free(blk); goto non;
        }
        nl->nr_free++;
    }
    nl->nr_free--;
    niffic_add_blk(blk, &(nl->used));
    nl->nr_used++;
    niffic_buffer_t *buf = blk->buf;
    memcpy(buf->buf, buf, sizeof(niffic_buffer_t));
    unsigned long cs = checksum(buf->buf);
    memcpy(buf->buf+sizeof(niffic_buffer_t)+blk_size, &cs, sizeof(unsigned long));
    pool->used += blk_size;
    return buf->buf+sizeof(niffic_buffer_t);
}
#endif

/*
 * free
 */
#ifdef __DEBUG
void niffic_free(void *ptr)
{
    free(ptr);
}
#else
void niffic_free(void *ptr)
{
    niffic_buffer_t *buf = (niffic_buffer_t *)(ptr-sizeof(niffic_buffer_t));
    niffic_list_t *nl = buf->list;
    niffic_pool_t *pool = buf->pool;
    niffic_block_t *blk = buf->blk;
    unsigned long cs = checksum(buf->buf);
    unsigned long old_cs, size = (((unsigned long)1)<<(nl - buf->pool->list));
    memcpy(&old_cs, buf->buf+sizeof(niffic_buffer_t)+size, sizeof(unsigned long));
    assert(cs==old_cs);
    niffic_del_blk(blk, &(nl->used));
    nl->nr_used--;
    pool->used -= size;
    nl->nr_free++;
    if( nl->nr_free+nl->nr_used>pool->nrblk_limit ) {
        niffic_free_blk(blk);
        nl->nr_free--;
    } else {
        memset(buf->buf, 0, size+ADDLEN);
        niffic_add_blk(blk, &(nl->free));
    }
}
#endif

/*
 * realloc
 */
#ifdef __DEBUG
void *niffic_realloc(void *ptr, unsigned long size)
{
    return realloc(ptr, size);
}
#else
void *niffic_realloc(void *ptr, unsigned long size)
{
    niffic_buffer_t *buf = (niffic_buffer_t *)(ptr-sizeof(niffic_buffer_t));
    niffic_list_t *nl = buf->list;
    niffic_pool_t *pool = buf->pool;
    unsigned long cs = checksum(buf->buf);
    unsigned long old_cs, old_size = (((unsigned long)1)<<(nl - buf->pool->list));
    memcpy(&old_cs, buf->buf+sizeof(niffic_buffer_t)+old_size, sizeof(unsigned long));
    assert(cs==old_cs);
    unsigned long len = old_size>size?size:old_size;
    void *new_ptr = niffic_alloc(pool, size);
    assert(new_ptr);
    memcpy(new_ptr, ptr, len);
    niffic_free(ptr);
    return new_ptr;
}
#endif

void niffic_print_pool(niffic_pool_t *pool)
{
    niffic_list_t *l, *lend = pool->list + (sizeof(long *)<<3);
    unsigned long nr_free = 0, nr_used = 0;
    niffic_block_t *blk;
    for(l = pool->list; l<lend; l++) {
        printf("size:%lu  nr_free:%lu  nr_used:%lu", \
        ((unsigned long)1)<<(l-pool->list), l->nr_free, l->nr_used);
        for(nr_free = 0, blk = l->free; blk!=NULL; blk = blk->next, nr_free++);
        for(nr_used = 0, blk = l->used; blk!=NULL; blk = blk->next, nr_used++);
        printf(" actual_free:%lu  actual_used:%lu\n", nr_free, nr_used);
    }
}

