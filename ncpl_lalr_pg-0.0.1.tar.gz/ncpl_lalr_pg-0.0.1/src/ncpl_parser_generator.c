
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<unistd.h>
#include<fcntl.h>
#include<assert.h>
#include<errno.h>
#include"ncpl_parser_generator.h"

static void init(int argc, char *argv[], struct param_lex_s *pls);
static int build_file_content(struct param_lex_s *pls, GENERATOR *gnt, RULE *r);
static int build_parser_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r);
static int build_include_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r);
static int build_embedded_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r);
static int build_header_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r);
static int build_rules(struct param_lex_s *pls, GENERATOR *gnt);
static int build_right_rule(struct param_lex_s *pls, GENERATOR *gnt, RULE *rule);
static void calc_nullable(GENERATOR *gnt);
static void calc_first(GENERATOR *gnt);
static int check_first(GENERATOR *gnt);
static void calc_follow(GENERATOR *gnt);
static void closure(STATE *s, GENERATOR *gnt);
static void Goto(STATE *s, GENERATOR *gnt);

static STATE *get_state_node(STATE *s, GENERATOR *gnt);
static int calc_items(STATE *s);
static int check_rule_repeat(RULE *r, STATE *s, CHARA *la);
static NCPL_LEX *get_lex(struct param_lex_s *pls, GENERATOR *gnt);
static CHARA *get_chara_node(NCPL_LEX *lex, GENERATOR *gnt);
static SET *get_set_node(CHARA *c, SET *set);
static void printb(FILE *fp, int nr_blank);
static int statecmp(STATE *s1, STATE *s2);
static int itemcmp(ITEM *i1, ITEM *i2);
static int lookaheadcmp(ITEM *i, CHARA *c);
static int calc_chara_number(GENERATOR *gnt);
static int map_atoi(char *str, GENERATOR *gnt);

static void build_lalr(GENERATOR *gnt);
static void move_lookahead_item(ITEM *dest, ITEM *src);
static void move_lookahead(STATE *dest, STATE *src);
static void fix_goto_state(STATE *state, int nr_state, int oldid, int newid);
static void rebuild_state_tbl(STATE *state, int nr_state, GENERATOR *gnt);
static void print(GENERATOR *gnt);
static void print_header_code(GENERATOR *gnt);
static void print_include_code(GENERATOR *gnt);
static void print_global_embedded_code(GENERATOR *gnt);
static void print_rules(GENERATOR *gnt);
static void print_nullable(GENERATOR *gnt);
static void print_first(GENERATOR *gnt);
static void print_follow(GENERATOR *gnt);
static void print_state(GENERATOR *gnt);
static void build_state_shift_table(GENERATOR *gnt);

static void create_header_file(GENERATOR *gnt);
static void build_header_structure(GENERATOR *gnt, FILE *fp);
static void build_header_embedded_code(GENERATOR *gnt, FILE *fp);
static void build_state_structure(GENERATOR *gnt, FILE *fp);
static void build_nonterminal_macro(GENERATOR *gnt, FILE *fp);
static void create_source_file(GENERATOR *gnt);
static void write_embedded_include_code(GENERATOR *gnt, FILE *fp);
static void build_state_tbl(GENERATOR *gnt, FILE *fp);
static void write_embedded_code(GENERATOR *gnt, FILE *fp);
static void build_reduce_func_tbl(GENERATOR *gnt, FILE *fp);
static void build_reduce_function(GENERATOR *gnt, FILE *fp);
static void build_reduce_function_content(RULE *r, GENERATOR *gnt, FILE *fp);
static void build_stack_components(GENERATOR *gnt, FILE *fp);
static void build_queue_component(GENERATOR *gnt, FILE *fp);
static void build_parse_component(GENERATOR *gnt, FILE *fp);

char parser_s_file[] = "ncpl_parser.c";
char parser_h_file[] = "ncpl_parser.h";

int main(int argc, char *argv[])
{
    struct param_lex_s pls;
    memset(&pls, 0, sizeof(pls));
    pls.pool = niffic_new_pool(N_M_INFINITE, 1);
    init(argc, argv, &pls);
    GENERATOR gnt;
    memset(&gnt, 0, sizeof(gnt));
    if( build_file_content(&pls, &gnt, NULL)<0 ) exit(1);
    calc_nullable(&gnt);
    calc_first(&gnt);
    if( check_first(&gnt)<0 ) {
        exit(1);
    }
    calc_follow(&gnt);
    Goto(NULL, &gnt);
    build_lalr(&gnt);
    print(&gnt);
    build_state_shift_table(&gnt);
    create_header_file(&gnt);
    create_source_file(&gnt);
    exit(0);
}

static void init(int argc, char *argv[], struct param_lex_s *pls)
{
    if( argc!=2 ) {
        fprintf(stderr, "%s gramma-file\n", argv[0]);
        exit(1);
    }
    strncpy(pls->file, argv[1], FILENAME-1);
    int fd;
    if( (fd = open(pls->file, O_RDONLY))<0 ) {
        fprintf(stderr, "Open %s failed. %s\n", pls->file, strerror(errno));
        exit(1);
    }
    pls->fd = fd;
    pls->len_buffer = 0;
    pls->len_token = LINELEN;
    pls->ch = -1;
    pls->line = 1;
    pls->ptr_token = (char *)niffic_alloc(pls->pool, pls->len_token);
    assert(pls->ptr_token);
}

//=====================================================================================
static int build_file_content(struct param_lex_s *pls, GENERATOR *gnt, RULE *r)
{
    NCPL_LEX *lex = gnt->lex==NULL?get_lex(pls, gnt):gnt->lex;
    while( 1 ) {
        if( lex->type==ENDFILE ) {
            break;
        } else if( lex->type==PERC ) {
            if( build_embedded_code(pls, gnt, r)<0 ) return -1;
        } else if( lex->type==EXCL ) {
            if( build_include_code(pls, gnt, r)<0 ) return -1;
        } else if( r==NULL && lex->type==LESS ) {
            if( build_parser_code(pls, gnt, r)<0 ) return -1;
        } else if( r==NULL && lex->type==POUND ) {
            if( build_header_code(pls, gnt, r)<0 ) return -1;
        } else if( r==NULL && lex->type==DOLLAR ) {
            lex = get_lex(pls, gnt);
            if( lex->type!=LBRACE ) goto err;
            if( build_rules(pls, gnt)<0 ) return -1;
        } else {
err:        fprintf(stderr, "%s(): Gramma-file '%s' Line:%d format error.\n", \
            __FUNCTION__, pls->file, pls->line); return -1;
        }
        if( r!=NULL ) return 0;
        lex = get_lex(pls, gnt);
    }
    return 0;
}

static int build_parser_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r)
{
    char *buf = NULL;
    if( ncpl_get_embedded_code(pls, (void **)(&buf))<0 ) return -1;
    EMBEDDED *e = create_embedded_node();
    e->buf = buf;
    add_embedded_node(e, &(gnt->p_head), &(gnt->p_tail));
    return 0;
}

static int build_include_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r)
{
    char *buf = NULL;
    if( ncpl_get_embedded_code(pls, (void **)(&buf))<0 ) return -1;
    EMBEDDED *e = create_embedded_node();
    e->buf = buf;
    add_embedded_node(e, &(gnt->inc_head), &(gnt->inc_tail));
    return 0;
}

static int build_header_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r)
{
    char *buf = NULL;
    if( ncpl_get_embedded_code(pls, (void **)(&buf))<0 ) return -1;
    EMBEDDED *e = create_embedded_node();
    e->buf = buf;
    add_embedded_node(e, &(gnt->he_head), &(gnt->he_tail));
    return 0;
}

static int build_embedded_code(struct param_lex_s *pls, GENERATOR *gnt, RULE *r)
{
    char *buf = NULL;
    if( ncpl_get_embedded_code(pls, (void **)(&buf))<0 ) return -1;
    EMBEDDED *e = create_embedded_node();
    e->buf = buf;
    if( r==NULL ) add_embedded_node(e, &(gnt->e_head), &(gnt->e_tail));
    else r->code = e;
    return 0;
}

static int build_rules(struct param_lex_s *pls, GENERATOR *gnt)
{
    NCPL_LEX *lex = get_lex(pls, gnt);
    if( lex->type==DOLLAR ) {
        if( !gnt->nr_rule ) {
            fprintf(stderr, "%s(): No rule in gramma-file '%s'.\n", \
            __FUNCTION__, pls->file); return -1;
        }
        gnt->rule_cnt = gnt->nr_rule;
        gnt->rule = (RULE *)calloc(gnt->rule_cnt, sizeof(RULE));
        assert(gnt->rule);
        return 0;
    }
    /*build left*/
    if( lex->type!=ID ) {
err:    fprintf(stderr, "%s(): %s:%d: Rule section format error.\n",\
        __FUNCTION__, pls->file, pls->line); return -1;
    }
    CHARA *left = get_chara_node(lex, gnt);
    if( left==NULL ) {
        TOKEN *t = create_token_node();
        t->lex = lex;
        t->is_terminal = 0;
        left = create_chara_node();
        left->token = t;
        add_chara_node(left, &(gnt->c_head), &(gnt->c_tail));
    } else {
        left->token->is_terminal = 0;
    }
    lex = get_lex(pls, gnt);
    if( lex->type!=COLON ) goto err;
    RULE r;
    memset(&r, 0, sizeof(r));
    r.left = left;
    /*build right*/
    if( build_right_rule(pls, gnt, &r)<0 ) return -1;
    /*recursion*/
    gnt->nr_rule++;
    if( build_rules(pls, gnt)<0 ) return -1;
    memcpy(&((gnt->rule)[gnt->rule_cnt-1]), &r, sizeof(RULE));
    gnt->rule_cnt--;
    return 0;
}

static int build_right_rule(struct param_lex_s *pls, GENERATOR *gnt, RULE *rule)
{
    int embedded_code = 0;
    CHARA *c;
    NCPL_LEX *lex = get_lex(pls, gnt);
    if( lex->type==SEMIC ) {
        rule->right_cnt = rule->nr_right;
        if( rule->nr_right ) {
            rule->right = (CHARA **)calloc(1, rule->nr_right*sizeof(CHARA **));
            assert(rule->right);
        } else {
            rule->left->is_nullable = 1;
        }
        return 0;
    }
    if( lex->type==PERC ) {
        if( build_file_content(pls, gnt, rule)<0 ) return -1;
        embedded_code = 1;
    } else if( lex->type==ID ) {
        c = get_chara_node(lex, gnt);
        if( c==NULL ) {
            TOKEN *t = create_token_node();
            t->lex = lex;
            t->is_terminal = 1;
            c = create_chara_node();
            c->token = t;
            add_chara_node(c, &(gnt->c_head), &(gnt->c_tail));
        }
        rule->nr_right++;
    } else {
        fprintf(stderr, "%s(): %s:%d: Production error.\n", \
        __FUNCTION__, pls->file, pls->line); return -1;
    }
    if( build_right_rule(pls, gnt, rule)<0 ) return -1;
    if( embedded_code ) return 0;
    rule->right[rule->right_cnt-1] = c;
    rule->right_cnt--;
    return 0;
}

//=====================================================================================

static void calc_nullable(GENERATOR *gnt)
{
    RULE *r, *rend;
    CHARA **c, **cend;
    int chg, null;
    while( 1 ) {
        chg = 0;
        rend = gnt->rule + gnt->nr_rule;
        for(r = gnt->rule; r<rend; r++) {
            null = 1;
            if( r->left->token->is_terminal )
                continue;
            if( r->left->is_nullable )
                continue;
            cend = r->right + r->nr_right;
            for(c = r->right; c<cend; c++ ) {
                if( !((*c)->is_nullable) ) {
                    null = 0;
                }
            }
            if( null ) {
                r->left->is_nullable = 1;
                chg = 1;
            }
        }
        if( !chg )
            break;
    }
}

static void calc_first(GENERATOR *gnt)
{
    RULE *r, *rend;
    CHARA **c, **cend, *scan;
    SET *s, *s2;
    int chg;
    for(scan = gnt->c_head; scan!=NULL; scan = scan->next) {
        if( scan->token->is_terminal ) {
            s = create_set_node();
            s->c = scan;
            add_set_node(s, &(scan->first_head), &(scan->first_tail));
        }
    }
    while( 1 ) {
        chg = 0;
        rend = gnt->rule + gnt->nr_rule;
        for(r = gnt->rule; r<rend; r++) {
            cend = r->right + r->nr_right;
            for(c = r->right; c<cend; c++) {
                for(s2 = (*c)->first_head; s2!=NULL; s2 = s2->next) {
                    s = get_set_node(s2->c, r->left->first_head);
                    if( s==NULL ) {
                        s = create_set_node();
                        s->c = s2->c;
                        add_set_node(s, &(r->left->first_head), &(r->left->first_tail));
                        chg = 1;
                    }
                }
                if( !((*c)->is_nullable) )
                    break;
            }
        }
        if( !chg )
            break;
    }
}

static int check_first(GENERATOR *gnt)
{
    int failed = 0;
    CHARA *c;
    for(c = gnt->c_head; c!=NULL; c = c->next) {
        if( c->token->is_terminal )
            continue;
        if( c->first_head==NULL ) {
            fprintf(stderr, "%s(): Nonterminal '%s' rule error. First Set is NULL.\n", \
            __FUNCTION__, c->token->lex->content);
            failed++;
        }
    }
    if( failed )
        return -1;
    return 0;
}

#define  FOLLOW_MARCO(); f = get_set_node(scan->c, c->follow_head);\
                        if( f==NULL ) {\
                            f = create_set_node();\
                            f->c = scan->c;\
                            add_set_node(f, &(c->follow_head), &(c->follow_tail));\
                            chg = 1;\
                        }
static void calc_follow(GENERATOR *gnt)
{
    int null, chg, i, j;
    RULE *r, *rend;
    CHARA *c, *la;
    SET *scan, *f;
    while( 1 ) {
        chg = 0;
        rend = gnt->rule + gnt->nr_rule;
        for(r = gnt->rule; r<rend; r++) {
            null = 1;
            for(i = r->nr_right - 1; i>=0; i--) {
                c = r->right[i];
                if( null && null==(r->nr_right - i) ) {
                    for(scan = r->left->follow_head; scan!=NULL; scan = scan->next) {
                        FOLLOW_MARCO();
                    }
                    for(j = 1; j<=null-1; j++) {
                        la = r->right[i+j];
                        for(scan = la->first_head; scan!=NULL; scan = scan->next) {
                            FOLLOW_MARCO();
                        }
                    }
                } else {
                    for(j = 1; j<=null+1; j++) {
                        la = r->right[i+j];
                        for(scan = la->first_head; scan!=NULL; scan = scan->next) {
                            FOLLOW_MARCO();
                        }
                    }
                }
                null = (c->is_nullable)?null+1:0;
            }
        }
        if( !chg )
            break;
    }
}

static void closure(STATE *s, GENERATOR *gnt)
{
    int chg, null;
    ITEM *it, *crt;
    SET *set, *laset;
    CHARA *c, *_c;
    RULE *r, *rend;
    while( 1 ) {
        chg = 0;
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->rule==NULL ) continue;
            if( it->rule->nr_right==it->pos ) continue;
            c = it->rule->right[it->pos];
            if( c->token->is_terminal ) continue;
            for(r = gnt->rule, rend = gnt->rule + gnt->nr_rule; r<rend; r++) {
                if( r->left!=c ) continue;
                null = 0;
                if( it->pos+1<it->rule->nr_right ) {
                    _c = it->rule->right[it->pos + 1];
                    for(set = _c->first_head; set!=NULL; set = set->next) {
                        if( check_rule_repeat(r, s, set->c) ) continue;
                        crt = create_item_node();
                        crt->pos = 0;
                        crt->rule = r;
                        laset = create_set_node();
                        laset->c = set->c;
                        add_set_node(laset, &(crt->la_head), &(crt->la_tail));
                        crt->input = it->input;
                        add_item_node(crt, &(s->i_head), &(s->i_tail));
                        chg = 1;
                    }
                }
                else null = 1;
                if( (null ||_c->is_nullable) && it->la_head!=NULL ) {
                    if( !check_rule_repeat(r, s, it->la_head->c) ) {
                        crt = create_item_node();
                        crt->pos = 0;
                        crt->rule = r;
                        if( it->la_head!=NULL ) {
                            laset = create_set_node();
                            laset->c = it->la_head->c;
                            add_set_node(laset, &(crt->la_head), &(crt->la_tail));
                        }
                        crt->input = it->input;
                        add_item_node(crt, &(s->i_head), &(s->i_tail));
                        chg = 1;
                    }
                }
            }
        }
        if( !chg )
            break;
    }
}

static void Goto(STATE *s, GENERATOR *gnt)
{
    if( s==NULL ) {
        s = create_state_node();
        s->id = (gnt->state_id)++;
        ITEM *i = create_item_node();
        i->rule = &(gnt->rule[0]);
        add_item_node(i, &(s->i_head), &(s->i_tail));
        add_state_node(s, &(gnt->s_head), &(gnt->s_tail));
        closure(s, gnt);
    }
    CHARA *scan;
    ITEM *it, *crt;
    STATE state, *cs;
    SET *laset;
    int match;
    for(scan = gnt->c_head; scan!=NULL; scan = scan->next) {
        match = 0;
        memset(&state, 0, sizeof(state));
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->rule->nr_right==it->pos ) continue;
            if( it->rule->right[it->pos]!=scan ) continue;
            match = 1;
            crt = create_item_node();
            crt->pos = it->pos + 1;
            crt->rule = it->rule;
            if( it->la_head!=NULL ) {
                assert(it->la_head->next==NULL);//every item only has one lookahead
                laset = create_set_node();
                laset->c = it->la_head->c;
                add_set_node(laset, &(crt->la_head), &(crt->la_tail));
            }
            crt->input = scan;
            it->read = scan;
            add_item_node(crt, &(state.i_head), &(state.i_tail));
        }
        if( !match ) continue;
        closure(&state, gnt);
        cs = get_state_node(&state, gnt);//check state existence.
        if( cs!=NULL ) {
            for(it = s->i_head; it!=NULL; it = it->next) {
                if( it->rule->nr_right==it->pos ) continue;
                if( it->rule->right[it->pos]==scan ) it->gotoi = cs->id;
            }
            clean_item_chain(&(state.i_head), &(state.i_tail));
            continue;
        }
        state.id = (gnt->state_id)++;
        cs = create_state_node();
        memcpy(cs, &state, sizeof(state));
        add_state_node(cs, &(gnt->s_head), &(gnt->s_tail));
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->rule->nr_right==it->pos ) continue;
            if( it->rule->right[it->pos]==scan ) it->gotoi = cs->id;
        }
        Goto(cs, gnt);
    }
}

/*components*/
static STATE *get_state_node(STATE *s, GENERATOR *gnt)
{
    STATE *scan;
    ITEM *i1, *i2;
    int failed, sum_s = calc_items(s), sum_scan;
    for(scan = gnt->s_head; scan!=NULL; scan = scan->next) {
        sum_scan = calc_items(scan);
        if( sum_scan!=sum_s ) continue;
        failed = 0;
        for(i1 = s->i_head; i1!=NULL; i1 = i1->next) {
            for(i2 = scan->i_head; i2!=NULL; i2 = i2->next) {
                if( i1->rule==i2->rule && \
                    i1->pos==i2->pos && \
                    i1->la_head->c==i2->la_head->c && \
                    i1->input==i2->input )
                    break;
            }
            if( i2==NULL ) failed++;
        }
        if( !failed ) return scan;
    }
    return NULL;
}

static int calc_items(STATE *s)
{
    ITEM *i;
    int cnt = 0;
    for(i = s->i_head; i!=NULL; i = i->next, cnt++)
        ;
    return cnt;
}

static int check_rule_repeat(RULE *r, STATE *s, CHARA *la)
{
    ITEM *it;
    for(it = s->i_head; it!=NULL; it = it->next) {
        if( it->rule==r && it->pos==0 && it->la_head->c==la )
            return 1;
    }
    return 0;
}

static NCPL_LEX *get_lex(struct param_lex_s *pls, GENERATOR *gnt)
{
    gnt->lex = ncpl_token(pls);
    return gnt->lex;
}

static CHARA *get_chara_node(NCPL_LEX *lex, GENERATOR *gnt)
{
    CHARA *scan;
    for(scan = gnt->c_head; scan!=NULL; scan = scan->next) {
        if( !strcmp(scan->token->lex->content, lex->content) && \
            scan->token->lex->type==lex->type )
        {
            return scan;
        }
    }
    return NULL;
}

static SET *get_set_node(CHARA *c, SET *set)
{
    for(; set!=NULL; set = set->next ) {
        if( set->c==c )
            return set;
    }
    return NULL;
}

static void printb(FILE *fp, int nr_blank)
{
    int i;
    for(i = 0; i<nr_blank; i++) fprintf(fp, " ");
}

static int statecmp(STATE *s1, STATE *s2)
{
    int sum_s1 = calc_items(s1), sum_s2 = calc_items(s2);
    if( sum_s1!=sum_s2 ) return 0;
    ITEM *i1, *i2;
    for(i1 = s1->i_head; i1!=NULL; i1 = i1->next) {
        for(i2 = s2->i_head; i2!=NULL; i2 = i2->next) {
            if( itemcmp(i1, i2) ) break;
        }
        if( i2==NULL ) return 0;
    }
    return 1;
}

static int itemcmp(ITEM *i1, ITEM *i2)
{
    if( i1==NULL || i2==NULL )
        return 0;
    if( i1->rule==i2->rule && i1->pos==i2->pos ) {
        assert(i1->input==i2->input);
        return 1;
    }
    return 0;
}

static int lookaheadcmp(ITEM *i, CHARA *c)
{
    SET *s = i->la_head;
    for(; s!=NULL; s = s->next) {
        if( s->c==c )
            return 1;
    }
    return 0;
}

static int calc_chara_number(GENERATOR *gnt)
{
    int cnt = NRALL;
    RULE *r, *rend = gnt->rule + gnt->nr_rule, *back;
    for(r = gnt->rule; r<rend; r++ ) {
        for(back = r-1; back>=gnt->rule; back--) {
            if( back->left==r->left ) break;
        }
        if( back>=gnt->rule ) continue;
        cnt++;
    }
    return cnt;
}

static int map_atoi(char *str, GENERATOR *gnt)
{
    int i = ncpl_lex_atoi(str);
    if( i>=0 )
        return i;
    int define_num = NRALL;
    RULE *r, *rend, *back;
    rend = gnt->rule + gnt->nr_rule;
    for(r = gnt->rule; r<rend; r++ ) {
        for(back = r-1; back>=gnt->rule; back--) {
            if( back->left==r->left )
                break;
        }
        if( back>=gnt->rule )
            continue;
        if( !strcmp(str, r->left->token->lex->content) )
            return define_num;
        define_num++;
    }
    return -1;
}

/*print begin=====================================================*/
static void print(GENERATOR *gnt)
{
    print_header_code(gnt);
    print_include_code(gnt);
    print_global_embedded_code(gnt);
    print_rules(gnt);
    print_nullable(gnt);
    print_first(gnt);
    print_follow(gnt);
    print_state(gnt);
}

static void print_include_code(GENERATOR *gnt)
{
    printf("EMBEDDED INCLUDE CODE:\n");
    EMBEDDED *e; int i = 0;
    for(e = gnt->inc_head; e!=NULL; e = e->next) {
        printf("BLOCK-%d:\n[%s]\n\n", i++, e->buf);
    }
}

static void print_header_code(GENERATOR *gnt)
{
    printf("EMBEDDED HEADER CODE:\n");
    EMBEDDED *e; int i = 0;
    for(e = gnt->he_head; e!=NULL; e = e->next) {
        printf("Block-%d:\n[%s]\n\n", i++, e->buf);
    }
}

static void print_global_embedded_code(GENERATOR *gnt)
{
    printf("GLOBAL EMBEDDED CODE:\n");
    EMBEDDED *e; int i = 0;
    for(e = gnt->e_head; e!=NULL; e = e->next) {
        printf("Block-%d:\n[%s]\n\n", i++, e->buf);
    }
}

static void print_rules(GENERATOR *gnt)
{
    printf("RULES:\n");
    RULE *r, *rend = gnt->rule + gnt->nr_rule;
    CHARA **c, **cend;
    printf("NR_RULE:%d\n", gnt->nr_rule);
    for(r = gnt->rule; r<rend; r++) {
        printf("NR_RIGHT:%d ", r->nr_right);
        printf("left: [%s] %s ", r->left->token->lex->content, \
        (r->left->token->is_terminal)?"Terminal":"Not Terminal");
        for(c = r->right, cend = r->right + r->nr_right; c<cend; c++) {
            printf("    right:[%s]%s", (*c)->token->lex->content, \
            ((*c)->token->is_terminal)?"Terminal":"Not Terminal");
        }
        printf("\n");
        if( r->code!=NULL )
            printf("embedded block:\n[%s]\n\n", r->code->buf);
    }
}

static void print_nullable(GENERATOR *gnt)
{
    CHARA *scan;
    printf("\nNULLABLE:\n");
    for(scan = gnt->c_head; scan!=NULL; scan = scan->next) {
        printf("\t\t[%s] %s:", scan->token->lex->content, \
        scan->is_nullable?"NULLABLE":"NON-NULLABLE");
        printf("\n");
    }
}

static void print_first(GENERATOR *gnt)
{
    SET *s;
    CHARA *scan;
    printf("\nFIRST:\n");
    for(scan = gnt->c_head; scan!=NULL; scan = scan->next) {
        printf("\t\t[%s] first:", scan->token->lex->content);
        for(s = scan->first_head; s!=NULL; s = s->next) {
            printf("   [%s]", s->c->token->lex->content);
        }
        printf("\n");
    }
}

static void print_follow(GENERATOR *gnt)
{
    SET *s;
    CHARA *scan;
    printf("\nFOLLOW:\n");
    for(scan = gnt->c_head; scan!=NULL; scan = scan->next) {
        printf("\t\t[%s] follow:", scan->token->lex->content);
        for(s = scan->follow_head; s!=NULL; s = s->next) {
            printf("   [%s]", s->c->token->lex->content);
        }
        printf("\n");
    }
}

static void print_state(GENERATOR *gnt)
{
    printf("\nSTATE:\n");
    STATE *st, *stend;
    ITEM *it;
    int i, k;
    CHARA *c;
    SET *la;
    for(st = gnt->state, \
        stend = gnt->state + gnt->nr_state; \
        st<stend; st++)
    {
        i = 0;
        printf("STATE-%d\n", st->id);
        printb(stdout, 2); printf("Items:\n");
        for(it = st->i_head; it!=NULL; it = it->next) {
            if( it->rule==NULL ) continue;
            printb(stdout, 4);
            printf("(%d) %s ->", i++, \
            it->rule->left->token->lex->content);
            if( !it->rule->nr_right ) printf(" .");
            for(k = 0; k<it->rule->nr_right; k++) {
                c = it->rule->right[k];
                if( k==it->pos ) printf(" .");
                printf(" %s", c->token->lex->content);
            }
            if( it->pos!=0&&it->pos==it->rule->nr_right ) printf(" .");
            if( it->la_head!=NULL ) {
                printb(stdout, 4); printf("LookAhead:");
                for(la = it->la_head; la!=NULL; la = la->next) {
                    printf(" %s", la->c->token->lex->content);
                }
            }
            printf("\n");
            if( it->input!=NULL ) {
                printb(stdout, 4);
                printf("Input: %s", it->input->token->lex->content);
            }
            if( it->read!=NULL ) {
                printb(stdout, 4);
                printf("Read: %s", it->read->token->lex->content);
            }
            if( it->gotoi>=0 ) {
                printb(stdout, 4);
                printf("goto state-id: %d", it->gotoi);
            }
            printf("\n");
        }
    }
}
/*print end=====================================================*/

static void build_lalr(GENERATOR *gnt)
{
    STATE *s, *send, *tmp;
    int nr_state = 0;
    for(s = gnt->s_head; s!=NULL; s = s->next, nr_state++)
        ;
    tmp = (STATE *)calloc(nr_state, sizeof(STATE));
    assert(tmp);
    for(s = gnt->s_head; s!=NULL; s = s->next) {
        memcpy(&(tmp[s->id]), s, sizeof(STATE));
    }
    /*item compress*/
    ITEM *i1, *i2, *fr;
    SET *la;
    for(s = tmp, send = tmp + nr_state; s<send; s++) {
        for(i1 = s->i_head; i1!=NULL; i1 = i1->next ) {
            for(i2 = i1->next; i2!=NULL; ) {
                if( itemcmp(i1, i2) ) {
                    fr = i2;
                    i2 = i2->next;
                    la = fr->la_head;
                    del_set_node(la, &(fr->la_head), &(fr->la_tail));
                    add_set_node(la, &(i1->la_head), &(i1->la_tail));
                    del_item_node(fr, &(s->i_head), &(s->i_tail));
                    continue;
                }
                i2 = i2->next;
            }
        }
    }
    /*state compress*/
    STATE *sc;
    for(s = tmp, send = tmp + nr_state; s<send; s++) {
        if( s->id<0 ) continue;
        for(sc = s + 1; sc<send; sc++) {
            if( sc->id<0 ) continue;
            if( statecmp(s, sc) ) {
                move_lookahead(s, sc);
                fix_goto_state(tmp, nr_state, sc->id, s->id);
                sc->id = -1;
            }
        }
    }
    /*rebuild table*/
    rebuild_state_tbl(tmp, nr_state, gnt);
    free(tmp);
}

static void move_lookahead_item(ITEM *dest, ITEM *src)
{
    SET *s = src->la_head, *la;
    while( s!=NULL ) {
        la = s;
        s = s->next;
        if( !lookaheadcmp(dest, la->c) ) {
            del_set_node(la, &(src->la_head), &(src->la_tail));
            add_set_node(la, &(dest->la_head), &(dest->la_tail));
        }
    }
}

static void move_lookahead(STATE *dest, STATE *src)
{
    ITEM *i1, *i2;
    for(i1 = dest->i_head; i1!=NULL; i1 = i1->next) {
        for(i2 = src->i_head; i2!=NULL; i2 = i2->next) {
            if( itemcmp(i1, i2) ) {
                move_lookahead_item(i1, i2);
            }
        }
    }
}

static void fix_goto_state(STATE *state, int nr_state, int oldid, int newid)
{
    STATE *s, *send;
    ITEM *it;
    for(s = state, send = state + nr_state; s<send; s++) {
        if( s->id<0 ) continue;
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->gotoi==oldid ) it->gotoi = newid;
        }
    }
}

static void rebuild_state_tbl(STATE *state, int nr_state, GENERATOR *gnt)
{
    STATE *s, *send;
    for(s = state, send = state + nr_state; s<send; s++) {
        if( s->id>=0 ) (gnt->nr_state)++;
    }
    gnt->state = (STATE *)calloc(gnt->nr_state, sizeof(STATE));
    assert(gnt->state);
    int i = 0;
    for(s = state, send = state + nr_state; s<send; s++) {
        if( s->id<0 ) continue;
        if( s->id!=i ) {
            fix_goto_state(state, nr_state, s->id, i);
            s->id = i;
        }
        memcpy(&(gnt->state[i]), s, sizeof(STATE));
        i++;
    }
}

static void build_state_shift_table(GENERATOR *gnt)
{
    gnt->shift_tbl = (SHIFT **)calloc(gnt->nr_state, sizeof(SHIFT *));
    assert(gnt->shift_tbl);
    gnt->nr_char = calc_chara_number(gnt);
    STATE *s, *send = gnt->state + gnt->nr_state;
    SHIFT *sw;
    ITEM *it;
    SET *la;
    int index, failed = 0, type;
    for(s = gnt->state; s<send; s++) {
        gnt->shift_tbl[s->id] = (SHIFT *)calloc(gnt->nr_char, sizeof(SHIFT));
        assert(gnt->shift_tbl[s->id]);
        sw = gnt->shift_tbl[s->id];
        for(it = s->i_head; it!=NULL; it = it->next) {
            if( it->pos==it->rule->nr_right ) {
                for(la = it->la_head; la!=NULL; la = la->next) {
                    index = map_atoi(la->c->token->lex->content, gnt);
                    if( sw[index].type!=PERROR && \
                    (sw[index].type!=PREDUCE || sw[index].index!=it->rule - gnt->rule) )
                    {
                        if( sw[index].type==PACCEPT || sw[index].type==PREDUCE )
                            fprintf(stderr, "ERROR: [%s] state %d Reduce-Reduce conflict.\n", \
                            la->c->token->lex->content, s->id);
                        else fprintf(stderr, "ERROR: [%s] state %d Shift-Reduce conflict.\n", \
                             la->c->token->lex->content, s->id);
                        failed++;
                    }
                    sw[index].type = PREDUCE;
                    sw[index].index = it->rule - gnt->rule;
                }
            } else {
                index = map_atoi(it->rule->right[it->pos]->token->lex->content, gnt);
                if( index==ENDFILE ) type = PACCEPT;
                else type = PSHIFT;
                if( sw[index].type!=PERROR && (sw[index].type!=type || sw[index].index!=it->gotoi) ) {
                    if( sw[index].type==PACCEPT || sw[index].type==PREDUCE )
                        fprintf(stderr, "ERROR: [%s] state %d Shift-Reduce conflict.\n", \
                        it->rule->right[it->pos]->token->lex->content, s->id);
                    else fprintf(stderr, "ERROR: [%s] state %d Shift-Shift conflict.\n", \
                         it->rule->right[it->pos]->token->lex->content, s->id);
                    failed++;
                }
                sw[index].type = type;
                sw[index].index = it->gotoi;
            }
        }
    }
    if( failed ) exit(1);
}

static void create_header_file(GENERATOR *gnt)
{
    if( access(parser_h_file, F_OK)>=0 ) {
        fprintf(stderr, "%s(): '%s' existed.\n", __FUNCTION__, parser_h_file);
        return ;
    }
    FILE *fp = fopen(parser_h_file, "w");
    if( fp==NULL ) {
        fprintf(stderr, "%s(): fopen error. %s\n", \
        __FUNCTION__, strerror(errno));
        exit(1);
    }
    fprintf(fp, "#ifndef __NCPL_PARSER_H\n");
    fprintf(fp, "#define __NCPL_PARSER_H\n");
    PRINT_TITLE(fp, "state_structure");
    build_header_structure(gnt, fp);
    build_state_structure(gnt, fp);
    PRINT_TITLE(fp, "nonterminal type macro");
    build_nonterminal_macro(gnt, fp);
    PRINT_TITLE(fp, "include & structures");
    build_header_embedded_code(gnt, fp);
    PRINT_TITLE(fp, "ncpl_parse");
    fprintf(fp, "extern int ncpl_parse(NCPL_PARSER *p, int type, int done);\n");
    fprintf(fp, "#endif\n");
    fclose(fp);
}

static void build_header_structure(GENERATOR *gnt, FILE *fp)
{
    /*include*/
    fprintf(fp, "#include\"ncpl_lex.h\"\n");
    /*define*/
    fprintf(fp, "#define _QLEN 10 /*greater than 1 then effective*/\n\n");
    fprintf(fp, "#define _CUR_STACK 1\n");
    fprintf(fp, "#define _OLD_STACK 2\n");
    fprintf(fp, "#define _ERR_STACK 3\n");
    /*stack*/
    fprintf(fp, "typedef struct ncpl_stack_s {\n");
    printb(fp, 4); fprintf(fp, "int type;\n");
    printb(fp, 4); fprintf(fp, "int in_state_no;\n");
    printb(fp, 4); fprintf(fp, "void *ptr;\n");
    printb(fp, 4); fprintf(fp, "struct ncpl_stack_s *next;\n");
    printb(fp, 4); fprintf(fp, "struct ncpl_stack_s *prev;\n");
    fprintf(fp, "}NCPL_STACK;\n\n");
    /*parser*/
    fprintf(fp, "typedef struct {\n");
    printb(fp, 4); fprintf(fp, "struct param_lex_s pls;\n");
    printb(fp, 4); fprintf(fp, "int cur_state;\n");
    printb(fp, 4); fprintf(fp, "int old_state;\n");
    printb(fp, 4); fprintf(fp, "int err_state;\n");
    printb(fp, 4); fprintf(fp, "int nr_queue;\n");
    printb(fp, 4); fprintf(fp, "int nr_err_queue;\n");
    printb(fp, 4); fprintf(fp, "int cur_reduce;\n");
    printb(fp, 4); fprintf(fp, "int old_reduce;\n");
    printb(fp, 4); fprintf(fp, "int err_reduce;\n");
    printb(fp, 4); fprintf(fp, "NCPL_LEX *cur_la;\n");
    printb(fp, 4); fprintf(fp, "NCPL_LEX *old_la;\n");
    printb(fp, 4); fprintf(fp, "NCPL_LEX *err_la;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *q_head;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *q_tail;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *err_q_head;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *err_q_tail;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *cur_stack;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *old_stack;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *err_stack;\n");
    printb(fp, 4); fprintf(fp, "niffic_pool_t *pool;\n");
    EMBEDDED *e;
    for(e = gnt->p_head; e!=NULL; e = e->next) {
        fprintf(fp, "%s\n", e->buf);
    }
    fprintf(fp, "}NCPL_PARSER;\n");
}

static void build_header_embedded_code(GENERATOR *gnt, FILE *fp)
{
    EMBEDDED *e;
    for(e = gnt->he_head; e!=NULL; e = e->next) {
        fprintf(fp, "%s\n", e->buf);
    }
}

static void build_state_structure(GENERATOR *gnt, FILE *fp)
{
    fprintf(fp, "#define PERROR 0\n");
    fprintf(fp, "#define PSHIFT 1\n");
    fprintf(fp, "#define PREDUCE 2\n");
    fprintf(fp, "#define PACCEPT 3\n\n");
    fprintf(fp, "typedef struct {\n");
    printb(fp, 4); fprintf(fp, "int type;\n");
    printb(fp, 4); fprintf(fp, "int index;\n");
    fprintf(fp, "} NCPL_STATE;\n\n");
}

static void build_nonterminal_macro(GENERATOR *gnt, FILE *fp)
{
    RULE *r, *rend = gnt->rule + gnt->nr_rule, *back;
    for(r = gnt->rule; r<rend; r++ ) {
        for(back = r-1; back>=gnt->rule; back--) {
            if( back->left==r->left ) break;
        }
        if( back>=gnt->rule ) continue;
        fprintf(fp, "#define %s %d\n", \
        r->left->token->lex->content, \
        map_atoi(r->left->token->lex->content, gnt));
    }
    fprintf(fp, "\n");
}

static void create_source_file(GENERATOR *gnt)
{
    if( access(parser_s_file, F_OK)>=0 ) {
        fprintf(stderr, "%s(): '%s' existed.\n", __FUNCTION__, parser_s_file);
        return ;
    }
    FILE *fp = fopen(parser_s_file, "w");
    if( fp==NULL ) {
        fprintf(stderr, "%s(): fopen error. %s\n", \
                     __FUNCTION__, strerror(errno));
        exit(1);
    }
    PRINT_TITLE(fp, "include & static declarations & local variables");
    write_embedded_include_code(gnt, fp);
    fprintf(fp, "#define DUMP_MOD 1\n");
    fprintf(fp, "#define DUMP_DEL 2\n");
    fprintf(fp, "#define DUMP_ADD 3\n\n");
    PRINT_TITLE(fp, "reduce function table");
    build_reduce_func_tbl(gnt, fp);
    PRINT_TITLE(fp, "state_table");
    build_state_tbl(gnt, fp);
    PRINT_TITLE(fp, "reduce functions");
    build_reduce_function(gnt, fp);
    PRINT_TITLE(fp, "stack components");
    build_stack_components(gnt, fp);
    PRINT_TITLE(fp, "queue components");
    build_queue_component(gnt, fp);
    PRINT_TITLE(fp, "parse components");
    build_parse_component(gnt, fp);
    write_embedded_code(gnt, fp);
    fclose(fp);
}

static void write_embedded_include_code(GENERATOR *gnt, FILE *fp)
{
    fprintf(fp, "#include<stdio.h>\n");
    fprintf(fp, "#include<stdlib.h>\n");
    fprintf(fp, "#include<string.h>\n");
    fprintf(fp, "#include<assert.h>\n");
    fprintf(fp, "#include\"niffic_alloc.h\"\n");
    fprintf(fp, "#include\"ncpl_parser.h\"\n");
    EMBEDDED *e;
    for(e = gnt->inc_head; e!=NULL; e = e->next) {
        fprintf(fp, "%s\n", e->buf);
    }
    fprintf(fp, "static NCPL_STACK *new_stack(niffic_pool_t *pool, void *ptr, int type, int cur_state);\n");
    fprintf(fp, "static void free_stack(NCPL_STACK *s);\n");
    fprintf(fp, "static void clean_stack(NCPL_STACK **stack);\n");
    fprintf(fp, "static void push(NCPL_STACK *s, NCPL_PARSER *p, int type);\n");
    fprintf(fp, "static NCPL_STACK *pop(NCPL_PARSER *p, int type);\n");
    fprintf(fp, "static void add_stack_queue(NCPL_STACK *s, NCPL_STACK **head, NCPL_STACK **tail);\n");
    fprintf(fp, "static void del_stack_queue(NCPL_STACK *s, NCPL_STACK **head, NCPL_STACK **tail);\n");
    fprintf(fp, "static NCPL_STACK *get_first_queue(NCPL_STACK **head, NCPL_STACK **tail);\n");
    fprintf(fp, "static void clean_stack_queue(NCPL_STACK **head, NCPL_STACK **tail);\n");
    fprintf(fp, "static void ncpl_err_dump(NCPL_PARSER *p, int position, int ctype, int opr);\n");
    fprintf(fp, "static void ncpl_recover(NCPL_PARSER *p, int position, int ctype, int opr);\n");
    fprintf(fp, "#define dupStackNode(pool, ori) \\\n");
    fprintf(fp, "new_stack((pool), (ori)->ptr, (ori)->type, (ori)->in_state_no)\n");
    fprintf(fp, "static void put_in_queue(NCPL_LEX *lex, NCPL_PARSER *p, int state);\n");
    fprintf(fp, "static NCPL_LEX *get_from_queue(NCPL_PARSER *p, int type);\n");
    fprintf(fp, "static int parse_err_process(NCPL_PARSER *p, int opr);\n");
}

static void build_state_tbl(GENERATOR *gnt, FILE *fp)
{
    fprintf(fp, "NCPL_STATE shift_tbl[%d][%d] = {\n", \
    gnt->nr_state, gnt->nr_char);
    STATE *s, *send = gnt->state + gnt->nr_state;
    int i, max_col = 8;
    for(s = gnt->state; s<send; s++) {
        fprintf(fp, "{");
        for(i = 0; i<gnt->nr_char; i++) {
            if( !(i%max_col) ) fprintf(fp, "\n");
            fprintf(fp, "{%d,%d}", \
            gnt->shift_tbl[s->id][i].type, \
            gnt->shift_tbl[s->id][i].index );
            if( i+1<gnt->nr_char ) fprintf(fp, ", ");
        }
        if( s+1<send ) fprintf(fp, "}, ");
        else fprintf(fp, "}\n");
    }
    fprintf(fp, "};\n\n");
}

static void write_embedded_code(GENERATOR *gnt, FILE *fp)
{
    EMBEDDED *e;
    for(e = gnt->e_head; e!=NULL; e = e->next) {
        fprintf(fp, "%s\n", e->buf);
    }
}

static void build_reduce_func_tbl(GENERATOR *gnt, FILE *fp)
{
    fprintf(fp, "typedef void (*RFT)(NCPL_PARSER *p, int type);\n\n");
    RULE *r, *rend = gnt->rule + gnt->nr_rule;
    for(r = gnt->rule; r<rend; r++) {
        fprintf(fp, "static void ncpl_%s_%d(NCPL_PARSER *p, int type);\n", \
        r->left->token->lex->content, r - gnt->rule);
    }
    fprintf(fp, "RFT reduce_func_tbl[%d] = {\n", gnt->nr_rule);
    for(r = gnt->rule; r<rend; r++) {
        fprintf(fp, "ncpl_%s_%d", \
        r->left->token->lex->content, r - gnt->rule);
        if( r+1<rend ) fprintf(fp, ",");
        fprintf(fp, "\n");
    }
    fprintf(fp, "};\n");
}

static void build_reduce_function(GENERATOR *gnt, FILE *fp)
{
    RULE *r, *rend = gnt->rule + gnt->nr_rule;
    for(r = gnt->rule; r<rend; r++) {
        fprintf(fp, "static void ncpl_%s_%d(NCPL_PARSER *p, int type)\n{\n", \
        r->left->token->lex->content, r - gnt->rule);
        build_reduce_function_content(r, gnt, fp);
        fprintf(fp, "}\n\n");
    }
}

static void build_reduce_function_content(RULE *r, GENERATOR *gnt, FILE *fp)
{
    printb(fp, 4); fprintf(fp, "int *state;\n");
    printb(fp, 4); fprintf(fp, "if( type==_CUR_STACK ) state = &(p->cur_state);\n");
    printb(fp, 4); fprintf(fp, "else if( type==_OLD_STACK ) state = &(p->old_state);\n");
    printb(fp, 4); fprintf(fp, "else state = &(p->err_state);\n");
    int i;
    for(i = 0; i<r->nr_right; i++) {
        printb(fp, 4); fprintf(fp, "NCPL_STACK *right%d = pop(p, type);\n", i);
    }
    printb(fp, 4);
    fprintf(fp, "NCPL_STACK *left = new_stack(p->pool, NULL, %s, *state);\n", \
    r->left->token->lex->content);
    if( r->code!=NULL ) {
        printb(fp, 4); fprintf(fp, "if( type==_OLD_STACK ) {\n");
        fprintf(fp, "%s\n", r->code->buf);
        printb(fp, 4); fprintf(fp, "}\n");
    }
    printb(fp, 4); fprintf(fp, "push(left, p, type);\n");
    for(i = 0; i<r->nr_right; i++) {
        printb(fp, 4); fprintf(fp, "free_stack(right%d);\n", i);
    }
}

static void build_stack_components(GENERATOR *gnt, FILE *fp)
{
    /*new_stack*/
    fprintf(fp, "static NCPL_STACK *\n");
    fprintf(fp, "new_stack(niffic_pool_t *pool, void *ptr, int type, int cur_state)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(pool);\n");
    printb(fp, 4);
    fprintf(fp, "NCPL_STACK *s = (NCPL_STACK *)niffic_alloc(pool, sizeof(NCPL_STACK));\n");
    printb(fp, 4); fprintf(fp, "assert(s);\n");
    printb(fp, 4); fprintf(fp, "s->ptr = ptr;\n");
    printb(fp, 4); fprintf(fp, "s->in_state_no = cur_state;\n");
    printb(fp, 4); fprintf(fp, "s->type = type;\n");
    printb(fp, 4); fprintf(fp, "return s;\n");
    fprintf(fp, "}\n\n");
    /*free_stack*/
    fprintf(fp, "static void free_stack(NCPL_STACK *s)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(s);\n");
    printb(fp, 4); fprintf(fp, "niffic_free(s);\n");
    fprintf(fp, "}\n\n");
    /*clean_stack*/
    fprintf(fp, "static void clean_stack(NCPL_STACK **stack)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(stack);\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *s = *stack, *f;\n");
    printb(fp, 4); fprintf(fp, "while( s!=NULL ) {\n");
    printb(fp, 8); fprintf(fp, "f = s; s = s->next;\n");
    printb(fp, 8); fprintf(fp, "free_stack(f);\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "*stack = NULL;\n");
    fprintf(fp, "}\n\n");
    /*push*/
    fprintf(fp, "static void push(NCPL_STACK *s, NCPL_PARSER *p, int type)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(s&&p);\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK **top = NULL;\n");
    printb(fp, 4); fprintf(fp, "switch( type ) {\n");
    printb(fp, 8); fprintf(fp, "case _CUR_STACK:\n");
    printb(fp, 12); fprintf(fp, "top = &(p->cur_stack); break;\n");
    printb(fp, 8); fprintf(fp, "case _OLD_STACK:\n");
    printb(fp, 12); fprintf(fp, "top = &(p->old_stack); break;\n");
    printb(fp, 8); fprintf(fp, "case _ERR_STACK:\n");
    printb(fp, 12); fprintf(fp, "top = &(p->err_stack); break;\n");
    printb(fp, 8); fprintf(fp, "default: assert(0);\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "if( *top==NULL ) {\n");
    printb(fp, 8); fprintf(fp, "*top = s;\n");
    printb(fp, 8); fprintf(fp, "return ;\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "s->next = *top;\n");
    printb(fp, 4); fprintf(fp, "*top = s;\n");
    fprintf(fp, "}\n\n");
    /*pop*/
    fprintf(fp, "static NCPL_STACK *pop(NCPL_PARSER *p, int type)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(p);\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK **top = NULL, *s;\n");
    printb(fp, 4); fprintf(fp, "int *state = NULL;\n");
    printb(fp, 4); fprintf(fp, "switch( type ) {\n");
    printb(fp, 8); fprintf(fp, "case _CUR_STACK:\n");
    printb(fp, 12); fprintf(fp, "top = &(p->cur_stack);\n");
    printb(fp, 12); fprintf(fp, "state = &(p->cur_state);\n");
    printb(fp, 12); fprintf(fp, "break;\n");
    printb(fp, 8); fprintf(fp, "case _OLD_STACK:\n");
    printb(fp, 12); fprintf(fp, "top = &(p->old_stack);\n");
    printb(fp, 12); fprintf(fp, "state = &(p->old_state);\n");
    printb(fp, 12); fprintf(fp, "break;\n");
    printb(fp, 8); fprintf(fp, "case _ERR_STACK:\n");
    printb(fp, 12); fprintf(fp, "top = &(p->err_stack);\n");
    printb(fp, 12); fprintf(fp, "state = &(p->err_state);\n");
    printb(fp, 12); fprintf(fp, "break;\n");
    printb(fp, 8); fprintf(fp, "default: assert(0);\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "s = *top;\n");
    printb(fp, 4); fprintf(fp, "*state = s->in_state_no;\n");
    printb(fp, 4); fprintf(fp, "*top = s->next;\n");
    printb(fp, 4); fprintf(fp, "s->next = s->prev = NULL;\n");
    printb(fp, 4); fprintf(fp, "return s;\n");
    fprintf(fp, "}\n\n");
    /*add_stack_queue*/
    fprintf(fp, "static void add_stack_queue(NCPL_STACK *s, NCPL_STACK **head, NCPL_STACK **tail)\n");
    fprintf(fp, "{\n");
    printb(fp, 4); fprintf(fp, "assert(s&&head&&tail);\n");
    printb(fp, 4); fprintf(fp, "if( *head==NULL ) {\n");
    printb(fp, 8); fprintf(fp, "*head = *tail = s;\n");
    printb(fp, 8); fprintf(fp, "return ;\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "(*tail)->next = s;\n");
    printb(fp, 4); fprintf(fp, "s->prev = *tail;\n");
    printb(fp, 4); fprintf(fp, "*tail = s;\n");
    fprintf(fp, "}\n\n");
    /*del_stack_queue*/
    fprintf(fp, "static void del_stack_queue(NCPL_STACK *s, NCPL_STACK **head, NCPL_STACK **tail)\n");
    fprintf(fp, "{\n");
    printb(fp, 4); fprintf(fp, "assert(s&&head&&tail);\n");
    printb(fp, 4); fprintf(fp, "if( s==*head ) {\n");
    printb(fp, 8); fprintf(fp, "if( s==*tail ) {\n");
    printb(fp, 12); fprintf(fp, "*head = *tail = NULL;\n");
    printb(fp, 8); fprintf(fp, "} else {\n");
    printb(fp, 12); fprintf(fp, "*head = s->next;\n");
    printb(fp, 12); fprintf(fp, "s->prev = NULL;\n");
    printb(fp, 8); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "} else {\n");
    printb(fp, 8); fprintf(fp, "if( s==*tail ) {\n");
    printb(fp, 12); fprintf(fp, "*tail = s->prev;\n");
    printb(fp, 12); fprintf(fp, "s->next = NULL;\n");
    printb(fp, 8); fprintf(fp, "} else {\n");
    printb(fp, 12); fprintf(fp, "s->prev->next = s->next;\n");
    printb(fp, 12); fprintf(fp, "s->next->prev = s->prev;\n");
    printb(fp, 8); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "s->next = s->prev = NULL;\n");
    fprintf(fp, "}\n\n");
    /*get_first_queue*/
    fprintf(fp, "static NCPL_STACK *get_first_queue(NCPL_STACK **head, NCPL_STACK **tail)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(head&&tail);\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *s = *head; assert(s);\n");
    printb(fp, 4); fprintf(fp, "*head = s->next;\n");
    printb(fp, 4); fprintf(fp, "if( *head!=NULL ) (*head)->prev = NULL;\n");
    printb(fp, 4); fprintf(fp, "if( s==*tail ) *tail = NULL;\n");
    printb(fp, 4); fprintf(fp, "s->prev = s->next = NULL;\n");
    printb(fp, 4); fprintf(fp, "return s;\n");
    fprintf(fp, "}\n\n");
    /*clean_stack_queue*/
    fprintf(fp, "static void clean_stack_queue(NCPL_STACK **head, NCPL_STACK **tail)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(head&&tail);\n");
    printb(fp, 4); fprintf(fp, "if( *head==NULL ) return ;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *s = *head, *fr;\n");
    printb(fp, 4); fprintf(fp, "while( s!=NULL ) {\n");
    printb(fp, 8); fprintf(fp, "fr = s; s = s->next;\n");
    printb(fp, 8); fprintf(fp, "free_stack(fr);\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "*head = *tail = NULL;\n");
    fprintf(fp, "}\n\n");
    /*ncpl_err_dump*/
    fprintf(fp, "static void ncpl_err_dump(NCPL_PARSER *p, int position, int ctype, int opr)\n{\n");
    printb(fp, 4); fprintf(fp, "clean_stack_queue(&(p->err_q_head), &(p->err_q_tail));\n");
    printb(fp, 4); fprintf(fp, "int cnt = 0;\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *s = p->q_head, *new;\n");
    printb(fp, 4); fprintf(fp, "for(; s!=NULL; s = s->next, cnt++) {\n");
    printb(fp, 8); fprintf(fp, "if( cnt==position && opr==DUMP_DEL ) continue;\n");
    printb(fp, 8); fprintf(fp, "new = dupStackNode(p->pool, s);\n");
    printb(fp, 8); fprintf(fp, "if( cnt==position ) ((NCPL_LEX *)(new->ptr))->type = ctype;\n");
    printb(fp, 8); fprintf(fp, "add_stack_queue(dupStackNode(p->pool, s), &(p->err_q_head), &(p->err_q_tail));\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "clean_stack(&(p->err_stack));\n");
    printb(fp, 4); fprintf(fp, "s = p->old_stack;\n");
    printb(fp, 4); fprintf(fp, "for(; s!=NULL; s = s->next)\n");
    printb(fp, 8); fprintf(fp, "push(dupStackNode(p->pool, s), p, _ERR_STACK);\n");
    printb(fp, 4); fprintf(fp, "p->err_state = p->old_state;\n");
    printb(fp, 4); fprintf(fp, "p->nr_err_queue = (opr==DUMP_DEL)?p->nr_queue-1:p->nr_queue;\n");
    printb(fp, 4); fprintf(fp, "p->err_la = p->old_la;\n");
    printb(fp, 4); fprintf(fp, "p->err_reduce = p->old_reduce;\n");
    fprintf(fp, "}\n\n");
    /*ncpl_recover*/
    fprintf(fp, "static void ncpl_recover(NCPL_PARSER *p, int position, int ctype, int opr)\n");
    fprintf(fp, "{\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *s;\n");
    printb(fp, 4); fprintf(fp, "int cnt = 0;\n");
    printb(fp, 4); fprintf(fp, "clean_stack(&(p->cur_stack));\n");
    printb(fp, 4); fprintf(fp, "for(s = p->err_stack; s!=NULL; s = s->next)\n");
    printb(fp, 8); fprintf(fp, "push(dupStackNode(p->pool, s), p, _CUR_STACK);\n");
    printb(fp, 4); fprintf(fp, "assert(p->cur_state==p->err_state);\n");
    printb(fp, 4); fprintf(fp, "p->cur_la = p->err_la;\n");
    printb(fp, 4); fprintf(fp, "p->cur_reduce = p->err_reduce;\n");
    printb(fp, 4); fprintf(fp, "if( opr==DUMP_DEL ) p->nr_queue--;\n");
    printb(fp, 4); fprintf(fp, "for(s = p->q_head; s!=NULL; s = s->next, cnt++) {\n");
    printb(fp, 8); fprintf(fp, "if( cnt==position ) break;\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "if( s==NULL ) return;\n");
    printb(fp, 4); fprintf(fp, "if( opr==DUMP_DEL ) {\n");
    printb(fp, 8); fprintf(fp, "del_stack_queue(s, &(p->q_head), &(p->q_tail));\n");
    printb(fp, 8); fprintf(fp, "free_stack(s);\n");
    printb(fp, 4); fprintf(fp, "} else {\n");
    printb(fp, 8); fprintf(fp, "((NCPL_LEX *)(s->ptr))->type = ctype;\n");
    printb(fp, 4); fprintf(fp, "}\n");
    fprintf(fp, "}\n\n");
}

static void build_queue_component(GENERATOR *gnt, FILE *fp)
{
    /*put_in_queue*/
    fprintf(fp, "static void put_in_queue(NCPL_LEX *lex, NCPL_PARSER *p, int state)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(lex&&p);\n");
    printb(fp, 4); fprintf(fp, "add_stack_queue(new_stack(p->pool, lex, lex->type, state),\\\n");
    printb(fp, 4); fprintf(fp, "&(p->q_head), &(p->q_tail));\n");
    printb(fp, 4); fprintf(fp, "p->nr_queue++;\n");
    fprintf(fp, "}\n\n");
    /*get_from_queue*/
    fprintf(fp, "static NCPL_LEX *get_from_queue(NCPL_PARSER *p, int type)\n{\n");
    printb(fp, 4); fprintf(fp, "assert(p);\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK *s;\n");
    printb(fp, 4); fprintf(fp, "if( type==_OLD_STACK ) {\n");
    printb(fp, 8); fprintf(fp, "assert(p->nr_queue>0);\n");
    printb(fp, 8); fprintf(fp, "s = get_first_queue(&(p->q_head), &(p->q_tail));\n");
    printb(fp, 8); fprintf(fp, "p->nr_queue--;\n");
    printb(fp, 4); fprintf(fp, "} else if( type==_ERR_STACK ) {\n");
    printb(fp, 8); fprintf(fp, "assert(p->nr_err_queue>0);\n");
    printb(fp, 8); fprintf(fp, "s = get_first_queue(&(p->err_q_head), &(p->err_q_tail));\n");
    printb(fp, 8); fprintf(fp, "p->nr_err_queue--;\n");
    printb(fp, 4); fprintf(fp, "} else assert(0);\n");
    printb(fp, 4); fprintf(fp, "NCPL_LEX *lex = (NCPL_LEX *)(s->ptr);\n");
    printb(fp, 4); fprintf(fp, "free_stack(s);\n");
    printb(fp, 4); fprintf(fp, "return lex;\n");
    fprintf(fp, "}\n\n");
    /*Q_IS_FULL*/
    fprintf(fp, "#define Q_IS_FULL(p) (p)->nr_queue>=_QLEN\n\n");
    /*Q_IS_Q_EMPTY*/
    fprintf(fp, "#define Q_IS_Q_EMPTY(p) (p)->nr_queue==0\n\n");
    /*Q_IS_ERRQ_EMPTY*/
    fprintf(fp, "#define Q_IS_ERRQ_EMPTY(p) (p)->nr_err_queue==0\n\n");
}

static void build_parse_component(GENERATOR *gnt, FILE *fp)
{
    /*parse_err_process*/
    fprintf(fp, "static int parse_err_process(NCPL_PARSER *p, int opr)\n{\n");
    printb(fp, 4); fprintf(fp, "int end = p->nr_queue>=_QLEN?_QLEN:p->nr_queue, pos, ctype;\n");
    printb(fp, 4); fprintf(fp, "for(pos = 0; pos<end; pos++) {\n");
    printb(fp, 8); fprintf(fp, "for(ctype = 0; ctype<NRALL; ctype++) {\n");
    printb(fp, 12); fprintf(fp, "ncpl_err_dump(p, pos, ctype, opr);\n");
    printb(fp, 12); fprintf(fp, "if( ncpl_parse(p, _ERR_STACK, 0)>=0 ) {\n");
    printb(fp, 16); fprintf(fp, "ncpl_recover(p, pos, ctype, opr);\n");
    printb(fp, 16); fprintf(fp, "return 0;\n");
    printb(fp, 12); fprintf(fp, "}\n");
    printb(fp, 8); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "return -1;\n");
    fprintf(fp, "}\n\n");
    /*macro P_GET_ARGS*/
    fprintf(fp, "#define P_GET_ARGS(p,type,top,la,state,reduce); \\\n");
    printb(fp, 4); fprintf(fp, "if( (type)==_CUR_STACK ) {\\\n");
    printb(fp, 8); fprintf(fp, "(top) = &((p)->cur_stack);\\\n");
    printb(fp, 8); fprintf(fp, "(la) = &((p)->cur_la);\\\n");
    printb(fp, 8); fprintf(fp, "(state) = &((p)->cur_state);\\\n");
    printb(fp, 8); fprintf(fp, "(reduce) = &((p)->cur_reduce);\\\n");
    printb(fp, 4); fprintf(fp, "} else if( (type)==_OLD_STACK ) {\\\n");
    printb(fp, 8); fprintf(fp, "(top) = &((p)->old_stack);\\\n");
    printb(fp, 8); fprintf(fp, "(la) = &((p)->old_la);\\\n");
    printb(fp, 8); fprintf(fp, "(state) = &((p)->old_state);\\\n");
    printb(fp, 8); fprintf(fp, "(reduce) = &((p)->old_reduce);\\\n");
    printb(fp, 4); fprintf(fp, "} else if( (type)==_ERR_STACK ) {\\\n");
    printb(fp, 8); fprintf(fp, "(top) = &((p)->err_stack);\\\n");
    printb(fp, 8); fprintf(fp, "(la) = &((p)->err_la);\\\n");
    printb(fp, 8); fprintf(fp, "(state) = &((p)->err_state);\\\n");
    printb(fp, 8); fprintf(fp, "(reduce) = &((p)->err_reduce);\\\n");
    printb(fp, 4); fprintf(fp, "} else assert(0);\n\n");
    /*macro P_PRE_READ*/
    fprintf(fp, "#define P_PRE_READ(p,type,top,la); \\\n");
    printb(fp, 4); fprintf(fp, "if( *(top)==NULL ) {\\\n");
    printb(fp, 8); fprintf(fp, "if( (type)==_CUR_STACK ) {\\\n");
    printb(fp, 12); fprintf(fp, "*(la) = ncpl_token(&((p)->pls)); assert(*(la));\\\n");
    printb(fp, 8); fprintf(fp, "} else if( (type)==_OLD_STACK || (type)==_ERR_STACK ) {\\\n");
    printb(fp, 12); fprintf(fp, "*(la) = get_from_queue((p), (type));\\\n");
    printb(fp, 8); fprintf(fp, "} else assert(0);\\\n");
    printb(fp, 4); fprintf(fp, "}\n\n");
    /*macro P_SHIFT*/
    fprintf(fp, "#define P_SHIFT(p,type,la,state,reduce,state_ptr,done); \\\n");
    printb(fp, 4); fprintf(fp, "if( !(*(reduce)) ) {\\\n");
    printb(fp, 8); fprintf(fp, "push(new_stack((p)->pool, *(la), (*(la))->type, *(state)), (p), (type));\\\n");
    printb(fp, 8); fprintf(fp, "if( (type)==_CUR_STACK ) {\\\n");
    printb(fp, 12); fprintf(fp, "put_in_queue(*(la), (p), *(state));\\\n");
    printb(fp, 12); fprintf(fp, "if( Q_IS_FULL((p)) ) assert(ncpl_parse((p), _OLD_STACK, 0)>=0);\\\n");
    printb(fp, 12); fprintf(fp, "*(la) = ncpl_token(&((p)->pls)); assert(*(la));\\\n");
    printb(fp, 8); fprintf(fp, "} else if( (type)==_OLD_STACK ) {\\\n");
    printb(fp, 12); fprintf(fp, "if( Q_IS_Q_EMPTY((p)) ) break;\\\n");
    printb(fp, 12); fprintf(fp, "*(la) = get_from_queue((p), (type));\\\n");
    printb(fp, 8); fprintf(fp, "} else {\\\n");
    printb(fp, 12); fprintf(fp, "if( Q_IS_ERRQ_EMPTY((p)) ) break;\\\n");
    printb(fp, 12); fprintf(fp, "*(la) = get_from_queue((p), (type));\\\n");
    printb(fp, 8); fprintf(fp, "}\\\n");
    printb(fp, 4); fprintf(fp, "}\\\n");
    printb(fp, 4); fprintf(fp, "*(state) = (state_ptr)->index;\\\n");
    printb(fp, 4); fprintf(fp, "if( (type)==_OLD_STACK && !(done) ) break;\\\n");
    printb(fp, 4); fprintf(fp, "*(reduce) = 0;\n\n");
    /*macro P_ERROR*/
    fprintf(fp, "#define P_ERROR(p,type,la,pos,failed,ctype); \\\n");
    printb(fp, 4); fprintf(fp, "if( (type)==_CUR_STACK ) {\\\n");
    printb(fp, 8); fprintf(fp, "(failed)++;\\\n");
    printb(fp, 8); fprintf(fp, "fprintf(stderr, \"%%s:%%d:%%d: Fatal error: illegal symbol before '%%s'.\\n\", \\\n");
    printb(fp, 8); fprintf(fp, "(p)->pls.file, (*(la))->line, (*(la))->off, \\\n");
    printb(fp, 8); fprintf(fp, "((*(la))->type==ENDFILE)?\"end of file\":(*(la))->content);\\\n");
    printb(fp, 8); fprintf(fp, "if( (*(la))->type==ENDFILE ) break;\\\n");
    printb(fp, 8); fprintf(fp, "if( parse_err_process((p), DUMP_MOD)>=0 ) continue;\\\n");
    printb(fp, 8); fprintf(fp, "if( parse_err_process((p), DUMP_DEL)<0 ) break;\\\n");
    printb(fp, 4); fprintf(fp, "} else if( (type)==_ERR_STACK ) return -1;\\\n");
    printb(fp, 4); fprintf(fp, "else assert(0);\n\n");
    /*ncpl_parse*/
    fprintf(fp, "int ncpl_parse(NCPL_PARSER *p, int type, int done)\n{\n");
    printb(fp, 4); fprintf(fp, "NCPL_STACK **top;\n");
    printb(fp, 4); fprintf(fp, "NCPL_LEX **la;\n");
    printb(fp, 4); fprintf(fp, "int *cur_state, *is_reduce;\n");
    printb(fp, 4); fprintf(fp, "P_GET_ARGS(p, type, top, la, cur_state, is_reduce);\n");
    printb(fp, 4); fprintf(fp, "P_PRE_READ(p, type, top, la);\n");
    printb(fp, 4); fprintf(fp, "NCPL_STATE *state; int state_type, col_num;\n");
    printb(fp, 4); fprintf(fp, "int failed = 0;\n");
    printb(fp, 4); fprintf(fp, "*is_reduce = 0;\n");
    printb(fp, 4); fprintf(fp, "while( 1 ) {\n");
    printb(fp, 8); fprintf(fp, "col_num = *is_reduce?(*top)->type:(*la)->type;\n");
    printb(fp, 8); fprintf(fp, "state = &shift_tbl[*cur_state][col_num];\n");
    printb(fp, 8); fprintf(fp, "state_type = state->type;\n");
    printb(fp, 8); fprintf(fp, "if( state_type==PSHIFT ) {\n");
    printb(fp, 12); fprintf(fp, "P_SHIFT(p, type, la, cur_state, is_reduce, state, done);\n");
    printb(fp, 8); fprintf(fp, "} else if( state_type==PREDUCE ) {\n");
    printb(fp, 12); fprintf(fp, "reduce_func_tbl[state->index](p, type);\n");
    printb(fp, 12); fprintf(fp, "*is_reduce = 1;\n");
    printb(fp, 8); fprintf(fp, "} else if( state_type==PERROR ) {\n");
    printb(fp, 12); fprintf(fp, "P_ERROR(p, type, la, pos, failed, ctype);\n");
    printb(fp, 8); fprintf(fp, "} else { /*PACCEPT*/\n");
    printb(fp, 12); fprintf(fp, "if( type==_CUR_STACK ) {\n");
    printb(fp, 16); fprintf(fp, "put_in_queue(*la, p, _OLD_STACK);\n");
    printb(fp, 16); fprintf(fp, "assert(ncpl_parse(p, _OLD_STACK, 1)>=0);\n");
    printb(fp, 12); fprintf(fp, "}\n");
    printb(fp, 12); fprintf(fp, "break;\n");
    printb(fp, 8); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "if( type==_CUR_STACK ) {\n");
    printb(fp, 8); fprintf(fp, "clean_stack_queue(&(p->err_q_head), &(p->err_q_tail));\n");
    printb(fp, 8); fprintf(fp, "clean_stack_queue(&(p->q_head), &(p->q_tail));\n");
    printb(fp, 8); fprintf(fp, "clean_stack(&(p->err_stack));\n");
    printb(fp, 8); fprintf(fp, "clean_stack(&(p->old_stack));\n");
    printb(fp, 4); fprintf(fp, "}\n");
    printb(fp, 4); fprintf(fp, "if( failed ) return -1;\n");
    printb(fp, 4); fprintf(fp, "return 0;\n");
    fprintf(fp, "}\n\n");
}

/*structures*/
    /*TOKEN*/
CREATE_NODE(TOKEN, create_token_node);
    /*SET*/
CREATE_NODE(SET, create_set_node);
ADD_NODE(SET, add_set_node);
DEL_NODE(SET, del_set_node);
    /*CHARA*/
CREATE_NODE(CHARA, create_chara_node);
ADD_NODE(CHARA, add_chara_node);
DEL_NODE(CHARA, del_chara_node);
    /*RULE*/
CREATE_NODE(RULE, create_rule_node);
    /*ITEM*/
ITEM *create_item_node(void)
{
    ITEM *i = (ITEM *)calloc(1, sizeof(ITEM));
    assert(i);
    i->gotoi = -1;
    return i;
}
ADD_NODE(ITEM, add_item_node);
DEL_NODE(ITEM, del_item_node);
CLEAN_CHAIN(ITEM, clean_item_chain);
    /*STATE*/
CREATE_NODE(STATE, create_state_node);
ADD_NODE(STATE, add_state_node);
DEL_NODE(STATE, del_state_node);
    /*EMBEDDED*/
CREATE_NODE(EMBEDDED, create_embedded_node);
ADD_NODE(EMBEDDED, add_embedded_node);
DEL_NODE(EMBEDDED, del_embedded_node);

