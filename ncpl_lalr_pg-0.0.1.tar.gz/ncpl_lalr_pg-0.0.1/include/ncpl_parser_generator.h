
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_PARSER_GENERATOR_H
#define __NCPL_PARSER_GENERATOR_H

#include"ncpl_lex.h"

#define PERROR 0
#define PSHIFT 1
#define PREDUCE 2
#define PACCEPT 3

typedef struct chara_s CHARA;
typedef struct state_s STATE;

typedef struct token_s {
    NCPL_LEX *lex;
    int is_terminal;
}TOKEN;

typedef struct set_s {
    CHARA *c;
    struct set_s *next;
    struct set_s *prev;
}SET;

struct chara_s {
    TOKEN *token;
    int is_nullable;
    SET *first_head;
    SET *first_tail;
    SET *follow_head;
    SET *follow_tail;
    struct chara_s *next;
    struct chara_s *prev;
};

typedef struct embedded_s {
    char *buf;
    struct embedded_s *next;
    struct embedded_s *prev;
}EMBEDDED;

typedef struct rule_s {
    int nr_right;
    int right_cnt;
    CHARA **right;
    CHARA *left;
    EMBEDDED *code;
}RULE;

typedef struct item_s {
    int pos;
    int gotoi;       //set in GOTO() last one is -1;
    RULE *rule;
    SET *la_head;           //first one NULL
    SET *la_tail;
    CHARA *input;         //first one NULL
    CHARA *read;         //last one NULL
    struct item_s *next;
    struct item_s *prev;
}ITEM;

struct state_s {
    int id;             //set in GOTO();
    ITEM *i_head;
    ITEM *i_tail;
    struct state_s *next;
    struct state_s *prev;
};

typedef struct {
    int type;
    int index;
}SHIFT;

typedef struct {
    int nr_rule;
    int rule_cnt;
    int state_id;
    int nr_state;
    int nr_char;// number of state shift table columes
    NCPL_LEX *lex;
    RULE *rule;
    CHARA *c_head;
    CHARA *c_tail;
    STATE *s_head; //init draft abort after rebuild_state_tbl()
    STATE *s_tail;
    STATE *state; //final table
    EMBEDDED *inc_head; //embedded source include code
    EMBEDDED *inc_tail;
    EMBEDDED *e_head;  //embedded source code
    EMBEDDED *e_tail;
    EMBEDDED *he_head; //embedded header code
    EMBEDDED *he_tail;
    EMBEDDED *p_head; //embedded parser code
    EMBEDDED *p_tail;
    SHIFT **shift_tbl;
}GENERATOR;

#define PRINT_TITLE(fp,str) fprintf((fp), "/*------------%s--------------*/\n",(str))

#define CREATE_NODE(type,name); \
     type *name(void)\
     {\
         type *t = (type *)calloc(1, sizeof(type));\
         assert(t); \
         return t; \
     }

#define ADD_NODE(type,name); \
    void name(type *t, type **head, type **tail)\
    {\
        if( *head==NULL ) \
            *head = *tail = t;\
        else {\
            (*tail)->next = t;\
            t->prev = *tail;\
            *tail = t;\
        }\
    }

#define DEL_NODE(type,name); \
    void name(type *t, type **head, type **tail) \
    {\
        if( *head==t ) {\
            if( *tail==t ) {\
                *head = *tail = NULL;\
            } else {\
                *head = t->next;\
                t->next->prev = NULL;\
            }\
        } else {\
            if( *tail==t ) {\
                *tail = t->prev;\
                t->prev->next = NULL;\
            } else {\
                t->prev->next = t->next;\
                t->next->prev = t->prev;\
            }\
        }\
        t->next = t->prev = NULL;\
    }

#define CLEAN_CHAIN(type,name); \
    void name(type **head, type **tail) \
    {\
        type *t = *head, *fr;\
        while( t!=NULL ) {\
            fr = t;\
            t = t->next;\
            free(fr);\
        }\
        *head = *tail = NULL;\
    }

extern TOKEN *create_token_node(void);
extern SET *create_set_node(void);
extern void add_set_node(SET *f, SET **head, SET **tail);
extern void del_set_node(SET *f, SET **head, SET **tail);
extern CHARA *create_chara_node(void);
extern void add_chara_node(CHARA *c, CHARA **head, CHARA **tail);
extern void del_chara_node(CHARA *c, CHARA **head, CHARA **tail);
extern RULE *create_rule_node(void);
extern ITEM *create_item_node(void);
extern void add_item_node(ITEM *i, ITEM **head, ITEM **tail);
extern void del_item_node(ITEM *i, ITEM **head, ITEM **tail);
extern STATE *create_state_node(void);
extern void add_state_node(STATE *s, STATE **head, STATE **tail);
extern void del_state_node(STATE *s, STATE **head, STATE **tail);
extern void clean_item_chain(ITEM **head, ITEM **tail);
extern EMBEDDED *create_embedded_node(void);
extern void add_embedded_node(EMBEDDED *e, EMBEDDED **head, EMBEDDED **tail);
extern void del_embedded_node(EMBEDDED *e, EMBEDDED **head, EMBEDDED **tail);

#endif

