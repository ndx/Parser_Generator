
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __NCPL_LEX_H
#define __NCPL_LEX_H

#include"niffic_alloc.h"

/*Common*/
#define SYLEN 16
#define FILENAME 256
#define NAMELEN 64
#define LINELEN 1024
#define NRSPEC 29
#define NRKEYW 1
#define END_OF_FILE 0x0
#define ERRRET (char)-1
/*Special charaters*/
#define NONE -1
#define EXCL 0 /*!*/
#define PERC 1 /*%*/
#define MUL 2 /***/
#define DIV 3 /*/*/
#define ADD 4 /*+*/
#define SUB 5 /*-*/
#define EQ   6 /*=*/
#define GREA 7 /*>*/
#define LESS 8 /*<*/
#define LBRACE 9 /*{*/
#define RBRACE 10 /*}*/
#define LBRACK 11 /*[*/
#define RBRACK 12 /*]*/
#define LPAREN 13 /*(*/
#define RPAREN 14 /*)*/
#define QUEST 15  /*?*/
#define COLON 16 /*:*/
#define SEMIC 17 /*;*/
#define POINT 18 /*.*/
#define COMMA 19 /*,*/
#define NEGATE 20 /*~*/
#define CHARAC 21 /*'*/
#define STRING 22 /*"*/
#define DOLLAR 23 /*$*/
#define AND 24 /*&*/
#define OR  25 /*|*/
#define BACKSLASH 26 /*\*/
#define POUND 27 /*#*/
#define XOR 28   /*^*/
#define RAND 29 /*&&*/
#define ROR  30 /*||*/
#define GEQUAL 31 /*>=*/
#define LEQUAL 32 /*<=*/
#define EQUAL 33 /*==*/
#define NEQUAL 34 /*!=*/
#define INC 35 /*++*/
#define DEC 36 /*--*/
/*other types*/
#define IDNUM 37
#define IONUM 38
#define IHNUM 39
#define FNUM 40
#define ID 41
#define COMMENT 42
/*Key words*/
#define KEYSTART IF
#define IF 43
#define ENDFILE 44
#define NRALL 45    /*number of all above*/

struct param_lex_s {
    char ch;
    int line;
    int offset;
    int fd;
    int len_buffer;
    int pos_buffer;
    int len_token;
    int pos_token;
    niffic_pool_t *pool;
    char ptr_buf[LINELEN];
    char *ptr_token;
    char file[FILENAME];
};

typedef struct lex_s {
    int type;
    int line;
    int off;
    int len;
    char *content;
}NCPL_LEX;

/*typedef*/
typedef NCPL_LEX *(*ncpl_keyf)(struct param_lex_s *pls, char *ch, int type);


/*declarations*/
#define ASSIGN(s,i,v) (s)->(i) = (v)
extern NCPL_LEX *ncpl_token(struct param_lex_s *pls);
extern char ncpl_getone(struct param_lex_s *pls);
extern void ncpl_put_in_buf(struct param_lex_s *pls);
extern int ncpl_translate(struct param_lex_s *pls, char ch);
extern NCPL_LEX *ncpl_create_lex_node(struct param_lex_s *pls, int type);
extern void ncpl_free_lex_node(NCPL_LEX *lex);
extern int ncpl_lex_atoi(char *str);  /*map all macro-strings to their integer*/
extern int ncpl_get_embedded_code(struct param_lex_s *pls, void **buf);

#endif

