#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<assert.h>
#include"ncpl_lex.h"

char token_type[NRALL][SYLEN] = {
"EXCL", "PERC", "MUL", "DIV",
"ADD", "SUB", "EQ", "GREA",
"LESS", "LBRACE", "RBRACE",
"LBRACK", "RBRACK", "LPAREN",
"RPAREN", "QUEST", "COLON",
"SEMIC", "POINT", "COMMA",
"NEGATE", "CHARACTER", "STRING",
"ENDFILE", "AND", "OR", "BACKSLASH",
"POUND", "XOR", "RAND", "ROR", "GRQUAL",
"LEQUAL", "EQUAL", "NEQUAL", "INC",
"DEC", "IDNUM", "IONUM", "IHNUM",
"FNUM", "ID", "COMMENT", "IF"
};


int main(int argc, char *argv[])
{
    if( argc!=2 ) {
        fprintf(stderr, "%s filepath\n", argv[0]);
        exit(1);
    }
    int fd = open(argv[1], O_RDONLY);
    if( fd<0 ) {
        perror("open");
        exit(1);
    }
    struct param_lex_s pls;
    memset(&pls, 0, sizeof(pls));
    strcpy(pls.file, argv[1]);
    pls.ch = -1;
    pls.line = 1;
    pls.fd = fd;
    pls.len_buffer = 0;
    pls.len_token = LINELEN;
    pls.pool = niffic_new_pool(N_M_INFINITE, 1);
    pls.ptr_token = (char *)niffic_alloc(pls.pool, pls.len_token);
    assert(pls.ptr_token);
    NCPL_LEX *lex = ncpl_token(&pls);
    while( lex!=NULL && lex->type!=ENDFILE ) {
        printf("%s[%s]\n", token_type[lex->type], lex->content);
        lex = ncpl_token(&pls);
    }
    if( lex==NULL ) {
        exit(1);
    }
    exit(0);
}

