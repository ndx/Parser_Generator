#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<assert.h>
#include"ncpl_lex.h"
#include"ncpl_parser.h"


int main(int argc, char *argv[])
{
    if( argc!=2 ) {
        fprintf(stderr, "%s filepath\n", argv[0]);
        exit(1);
    }
    int fd = open(argv[1], O_RDONLY);
    if( fd<0 ) {
        perror("open");
        exit(1);
    }
    NCPL_PARSER p;
    memset(&p, 0, sizeof(p));
    strcpy(p.pls.file, argv[1]);
    p.pls.ch = -1;
    p.pls.line = 1;
    p.pls.fd = fd;
    p.pls.len_buffer = 0;
    p.pls.len_token = LINELEN;
    p.pls.pool = niffic_new_pool(N_M_INFINITE, 1);
    p.pool = niffic_new_pool(N_M_INFINITE, 512);
    p.pls.ptr_token = (char *)niffic_alloc(p.pls.pool, p.pls.len_token);
    assert(p.pls.ptr_token);
    if( ncpl_parse(&p, _CUR_STACK, 0)<0 ) {
        fprintf(stderr, "parse error.\n");
        exit(1);
    }
    printf("Parse succeed.\n");
    /*free all*/
    exit(0);
}

